import { Component, OnInit } from '@angular/core';
import {  FormGroup, FormControl} from '@angular/forms';
import { HttpClient } from "@angular/common/http";
import { Observable} from 'rxjs';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  constructor(private httpClient:HttpClient) { }
  RegistrationForm = new FormGroup({
    Username: new FormControl(''),
    Password: new FormControl(''),
    Name: new FormControl(''),
    Email: new FormControl(''),
    PhoneNo: new FormControl('')  
  });

  ngOnInit() {
  }

  onSubmit() {
    // TODO: Use EventEmitter with form value
    //http://localhost:49728/api/Common/SaveUser
    // public string Name { get; set; }
    // public string Username { get; set; }
    // public string Password { get; set; }
    // public string EmailID { get; set; }
    // public string EmailID { get; set; }       
    //console.warn(this.RegistrationForm.value);
    this.httpClient.post("http://localhost:49728/api/Common/SaveUser",
    {
        "Name": "Customer004",
        "Username": "customer004@email.com",
        "Password": "0000252525",
        "EmailID": "0000252525",
        "PhoneNo ": "0000252525"
    })
    .subscribe(
        data => {
            console.log("POST Request is successful ", data);
        },
        error => {
            console.log("Error", error);
        }
    );         
  }
}
