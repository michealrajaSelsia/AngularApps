import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editapplication',
  templateUrl: './editapplication.component.html',
  styleUrls: ['./editapplication.component.css']
})
export class EditapplicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
