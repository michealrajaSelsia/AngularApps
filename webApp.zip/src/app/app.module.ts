import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HomeComponent } from './Public/home/home.component';
import { AboutusComponent } from './Public/aboutus/aboutus.component';
import { HistoryComponent } from './Public/history/history.component';
import { ContactusComponent } from './Public/contactus/contactus.component';
import { GalaryComponent } from './Public/galary/galary.component';
import { RegistrationComponent } from './Student/registration/registration.component';
import { EditapplicationComponent } from './Student/editapplication/editapplication.component';
import { ApplicationStatusComponent } from './Student/application-status/application-status.component';
import { StudentHomeComponent } from './Student/student-home/student-home.component';
import { AdminloginComponent } from './Shared/adminlogin/adminlogin.component';
import { ReportComponent } from './Admin/report/report.component';
import { ApproveApplicationComponent } from './Admin/approve-application/approve-application.component';
import { AdminDashBoardComponent } from './Admin/admin-dash-board/admin-dash-board.component';
import { MyProfileComponent } from './Student/my-profile/my-profile.component';

import { AdminmenuComponent } from './Shared/adminmenu/adminmenu.component';
import { StudentmenuComponent } from './Shared/studentmenu/studentmenu.component';
import { CommonMenuComponent } from './Shared/common-menu/common-menu.component';
import { LayoutComponent } from './Shared/layout/layout.component';
import { StudentloginComponent } from './Shared/studentlogin/studentlogin.component';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import { MaterialAppModule } from './MainConfig/ngmaterial.module';
import {UniverSityCroutingConfigModule} from './MainConfig/routing.config.module';
import { HeaderComponent } from './shared/header/header.component';
import { FooderComponent } from './shared/fooder/fooder.component';
import { StudentDashBoardComponent } from './student/student-dash-board/student-dash-board.component';
import { ForgetPasswordComponent } from './Shared/forget-password/forget-password.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutusComponent,
    HistoryComponent,
    ContactusComponent,
    GalaryComponent,
    RegistrationComponent,
    EditapplicationComponent,
    ApplicationStatusComponent,
    StudentHomeComponent,
    AdminloginComponent,
    ReportComponent,
    ApproveApplicationComponent,
    AdminDashBoardComponent,
    MyProfileComponent,
    AdminmenuComponent,
    StudentmenuComponent,
    CommonMenuComponent,
    LayoutComponent,
    StudentloginComponent,
    HeaderComponent,
    FooderComponent,
    StudentDashBoardComponent,
    ForgetPasswordComponent
     ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,   
    MatButtonModule,
    MatCheckboxModule,
    MaterialAppModule,
    UniverSityCroutingConfigModule,
    FormsModule, ReactiveFormsModule ,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
