import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentlogin',
  templateUrl: './studentlogin.component.html',
  styleUrls: ['./studentlogin.component.css']
})
export class StudentloginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
