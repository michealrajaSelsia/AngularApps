import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fooder',
  templateUrl: './fooder.component.html',
  styleUrls: ['./fooder.component.css']
})
export class FooderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
