import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroupDirective, NgForm, Validators, FormGroup, FormControlName} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { MaterialAppModule} from '../../MainConfig/ngmaterial.module';
import { Router} from '@angular/router';
import {UserService} from '../../Services/public-api.service';
import { ContactUS} from '../../Models/Public/ContactUsModel';
@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

  objContactUS:ContactUS;
  constructor( private myApiService: UserService) { }

  ngOnInit() {
  }

  ContactForm=new FormGroup({
    Name:new FormControl(''),
    Email:new FormControl(''),
    Subject:new FormControl(''),
    Message:new FormControl('')
  });

  onSubmit()
  {
    this.objContactUS = Object.assign({}, this.ContactForm.value);

    this.myApiService.saveContactUsData(this.objContactUS).subscribe(
      data => {
          console.log("POST Request is successful ", data)         
          alert("Successfully registred")       
          
      },
      error => {
          console.log("Error", error);
      }
  );         ;
  }
}
