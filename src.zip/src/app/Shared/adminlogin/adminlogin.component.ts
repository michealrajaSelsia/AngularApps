import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroupDirective, NgForm, Validators, FormGroup, FormControlName} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { MaterialAppModule} from '../../MainConfig/ngmaterial.module';
import { Router} from '@angular/router';
@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  AdminLoginForm=new FormGroup({
    _Username:new FormControl(''),
    _Password:new FormControl('')
  });
  constructor( private route:Router) { }
  ngOnInit() {
   
  }

  onLoginSubmit() {
    // TODO: Use EventEmitter with form value
    console.warn(this.AdminLoginForm.value);
    this.route.navigate(['MyAdminHome']);
  }
  
}
