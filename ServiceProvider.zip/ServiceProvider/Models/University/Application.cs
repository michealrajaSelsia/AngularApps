﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceProvider.Models
{
    public class Application
    {
        public string ApplicationID { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Fullname { get; set; }
        public DateTime DOB { get; set; }
        public int Gender { get; set; }
        public string FatherName { get; set; }
        public string MotherName { get; set; }
        public string Religion { get; set; }
        public string Email { get; set; }
        public int MobileNo { get; set; }
        public string Address { get; set; }
        public string SSLCSchoolName { get; set; }
        public string SSLCMark { get; set; }
        public string SSLCPercentage { get; set; }
        public string HSCSchoolName { get; set; }
        public string HSCMainSubject { get; set; }
        public string HSCMark { get; set; }
        public string HSCPercentage { get; set; }
        public DateTime CreateOn { get; set; }
    }
}