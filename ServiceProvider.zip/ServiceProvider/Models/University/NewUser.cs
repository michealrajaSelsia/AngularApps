﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceProvider.Models.University
{
    public class NewUser
    {       
        public string Name { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string EmailID { get; set; }
        public string PhoneNo { get; set; }       
    }
    public class UserLogin
    {    
        public string Username { get; set; }
        public string Password { get; set; }
    }
}