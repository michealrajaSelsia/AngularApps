﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceProvider.Models.Common
{
    public class Employee
    {
        public string empid { get; set; }
        public string name { get; set; }
        public string department { get; set; }
        public string phoneNo { get; set; }
        public string empAddress { get; set; }
    }
}