﻿using ServiceProvider.Models;
using ServiceProvider.Models.University;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using ServiceProvider.Models.Common;

namespace ServiceProvider.Controllers.University
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
   
    public class CommonController : ApiController
    {
        SqlConnectionStringBuilder sqlString = new SqlConnectionStringBuilder();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlDataReader dr;
        CommonController()
        {
            sqlString.DataSource = "DESKTOP-F231U8O\\MICHEALKING";
            sqlString.InitialCatalog = "University";
            sqlString.IntegratedSecurity = true;
        }

        //http://localhost:49728/api/Common/GetData?tblName=GetCourses
        //http://localhost:49728/api/Common/GetData?tblName=GetApplication
        //http://localhost:49728/api/Common/GetData?tblName=GetApplicationStatus
        //http://localhost:49728/api/Common/GetData?tblName=GetCourses
        //http://localhost:49728/api/Common/GetData?tblName=GetReligion
        //http://localhost:49728/api/Common/GetData?tblName=GetUserDetails

        [HttpGet]
        public IHttpActionResult GetData(string tblName)
        {
            DataSet ds = new DataSet("TimeRanges");
            try
            {
                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand(tblName, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        //con.Open();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            finally
            {

            }
            return Json(ds);
        }


        //http://localhost:49728/api/Common/ValidateAdminLogin?Username=Admin&Password=Admin
        [HttpPost]
        public IHttpActionResult ValidateAdminLogin(UserLogin obj)
        {
   
            Boolean isAdmin = false;

            try
            {

                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand("ValidateAdminLogin", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Username",obj.Username);
                        cmd.Parameters.AddWithValue("@Password", obj.Password);
                        con.Open();
                        isAdmin = Convert.ToBoolean(cmd.ExecuteScalar());
                        return Json(isAdmin);
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            finally
            {

            }
        }


        //http://localhost:49728/api/Common/ValidateUserLogin?Username=Micheal1&Password=Micheal1
        [HttpPost]
        public IHttpActionResult ValidateUserLogin(UserLogin obj)
        {
            Boolean isAdmin = false;            
            try
            {

                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand("[ValidateUserLogin]", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Username", obj.Username);
                        cmd.Parameters.AddWithValue("@Password", obj.Password);
                        con.Open();
                        isAdmin = Convert.ToBoolean(cmd.ExecuteScalar());
                        return Json(isAdmin);
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            finally
            {

            }


        }

        [HttpPost]
        public IHttpActionResult UpdateApplicationStatus(ApplicationStatus objNewUser)
        {
            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("ApplicationID", typeof(string));
                dt.Columns.Add("ApprovedStatus", typeof(string));
                dt.Columns.Add("ApprovedBy", typeof(string));
                dt.Columns.Add("ApplicationComment", typeof(string));
                dt.Columns.Add("ApprovedOn", typeof(DateTime));

                dt.Rows.Add(
                            objNewUser.ApplicationID,
                            objNewUser.ApprovedStatus,
                            objNewUser.ApprovedBy,
                            objNewUser.ApplicationComment,
                            objNewUser.ApprovedOn
                            );

                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdateApplicationStatus", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ApplicationStatus", dt);
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            finally
            {

            }
            return Json("Success");

        }

        [HttpPost]
        //http://localhost:49728/api/Common/SaveUser
        public IHttpActionResult SaveUser(NewUser objNewUser)
        {
            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Userid", typeof(string));
                dt.Columns.Add("Name", typeof(string));
                dt.Columns.Add("Username", typeof(string));
                dt.Columns.Add("Password", typeof(string));
                dt.Columns.Add("EmailID", typeof(string));
                dt.Columns.Add("PhoneNo", typeof(string));
                dt.Columns.Add("Createdon", typeof(DateTime));
                dt.Columns.Add("isActive", typeof(int));

                dt.Rows.Add( "",
                            objNewUser.Name,
                            objNewUser.Username,
                            objNewUser.Password,
                            objNewUser.EmailID,
                            objNewUser.PhoneNo,
                            DateTime.Now,
                            1
                            );

                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdateUser", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@UserRegistration", dt);
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex) { return Json("Failed" + ex.Message.ToString()); }
            finally { }
            return Json("Success");
        }

        [HttpPost]
        public IHttpActionResult SaveContactUs(ContactUS objContactus)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Email", typeof(string));
            dt.Columns.Add("Subject", typeof(string));
            dt.Columns.Add("Message", typeof(string));
            dt.Rows.Add(
                objContactus.Name,
                objContactus.Email,
                objContactus.Subject,
                objContactus.Message
                );
            try
            {

           
            using (SqlConnection con = new SqlConnection(sqlString.ToString()))
            {
                using (SqlCommand cmd = new SqlCommand("saveContactUS", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ContactUStbl", dt);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            return Json("Success");
        }

        //http://localhost:49728/api/Common/addApplication
        [HttpPost]
        public IHttpActionResult addApplication(Application objApplication)
        {
            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("ApplicationID", typeof(string));
                dt.Columns.Add("Fname", typeof(string));
                dt.Columns.Add("Lname", typeof(string));
                dt.Columns.Add("Fullname", typeof(string));
                dt.Columns.Add("DOB", typeof(DateTime));
                dt.Columns.Add("Gender", typeof(int));
                dt.Columns.Add("FatherName", typeof(string));
                dt.Columns.Add("MotherName", typeof(string));
                dt.Columns.Add("Religion", typeof(string));
                dt.Columns.Add("Email", typeof(string));
                dt.Columns.Add("MobileNo", typeof(int));
                dt.Columns.Add("Address", typeof(string));
                dt.Columns.Add("SSLCSchoolName", typeof(string));
                dt.Columns.Add("SSLCMark", typeof(string));
                dt.Columns.Add("SSLCPercentage", typeof(string));
                dt.Columns.Add("HSCSchoolName", typeof(string));
                dt.Columns.Add("HSCMainSubject", typeof(string));
                dt.Columns.Add("HSCMark", typeof(string));
                dt.Columns.Add("HSCPercentage", typeof(string));
                dt.Columns.Add("CreateOn", typeof(DateTime));

                dt.Rows.Add(
                    objApplication.ApplicationID,
                    objApplication.Fname,
                    objApplication.Lname,
                    objApplication.Fullname,
                    objApplication.DOB,
                    objApplication.Gender,
                    objApplication.FatherName,
                    objApplication.MotherName,
                    objApplication.Religion,
                    objApplication.Email,
                    objApplication.MobileNo,
                    objApplication.Address,
                    objApplication.SSLCSchoolName,
                    objApplication.SSLCMark,
                    objApplication.SSLCPercentage,
                    objApplication.HSCSchoolName,
                    objApplication.HSCMainSubject,
                    objApplication.HSCMark,
                    objApplication.HSCPercentage,
                    objApplication.CreateOn
                    );


                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdateApplication", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@TempApplication", dt);
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            finally
            {

            }
            return Json("Success");
        }


        //http://localhost:49728/api/Common/GetGalleryImages
        [HttpGet]
        public IHttpActionResult GetGalleryImages()
        {
            DataSet ds = new DataSet("TimeRanges");
            List<GalleryModel> imgCollection = new List<GalleryModel>();
            try
            {
                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand("GetGalleryImages", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        SqlDataAdapter da = new SqlDataAdapter();
                        da.SelectCommand = cmd;
                        da.Fill(ds);

                        DataTable dt = new DataTable();
                        dt = ds.Tables[0];
                        foreach (DataRow dr in dt.Rows)
                        {
                            imgCollection.Add(
                                new GalleryModel
                                {
                                    Id = Convert.ToInt32(dr["Id"]),
                                    Name = Convert.ToString(dr["Name"]),
                                    ImgPath = Convert.ToString(dr["ImgPath"]),
                                    Description = Convert.ToString(dr["Description"]),
                                    Liked = Convert.ToString(dr["Liked"]),
                                    DisLiked = Convert.ToString(dr["DisLiked"])
                                });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            finally
            {

            }
            return Json(imgCollection);
        }


        // GET: api/Common
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Common/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Common
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Common/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Common/5
        public void Delete(int id)
        {
        }
    }
}
